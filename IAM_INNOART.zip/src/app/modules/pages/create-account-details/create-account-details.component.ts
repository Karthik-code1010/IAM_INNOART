import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-account-details',
  templateUrl: './create-account-details.component.html',
  styleUrls: ['./create-account-details.component.scss']
})
export class CreateAccountDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  product = 'Product';
  deployment_type ='On-Premises'

  startDate = new Date();
}
