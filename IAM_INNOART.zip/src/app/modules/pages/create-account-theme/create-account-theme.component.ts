import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-account-theme',
  templateUrl: './create-account-theme.component.html',
  styleUrls: ['./create-account-theme.component.scss']
})
export class CreateAccountThemeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  country = 'India';
  state = 'chennai';
}
