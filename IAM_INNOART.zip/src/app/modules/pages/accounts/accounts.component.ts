import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AccountDialogComponent } from '../account-dialog/account-dialog.component';
import { ColumnDialog } from '../column-dialog/column-dialog';
export interface PeriodicElement {
  id: string;
  groupname:string;
  status:string;
  createdat: string;
  updatedat: string;
  createdby: string;



}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 'PE00001', groupname: 'User', status: 'Active', createdat: '11-09-2021 21:09:21',updatedat:'11-19-2021 21:09:21',createdby:'Administrator'},
 
];

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {

  constructor(private dialog: MatDialog,) { }

  ngOnInit(): void {
    this.displayedColumns = [];
    this.allColumns.forEach(element => {
      if (element.activeFlag) {
        this.displayedColumns.push(element.name);
      }
    });
  }

  displayedColumns: string[] = [];
  allColumns = [
    { name: 'id', activeFlag: true, displayName: "ID" },
    { name: 'groupname', activeFlag: true, displayName: "Type" }, 
    { name: 'status', activeFlag: true, displayName: "Name" },
   
    { name: 'createdat', activeFlag: true, displayName: "Created At" },
     { name: 'updatedat', activeFlag: true, displayName: "Modified At" }, 
     { name: 'createdby', activeFlag: true, displayName: "created by" }, 
     { name: 'action', activeFlag: true, displayName: "action" }
    
    ];


 // displayedColumns: string[] = ['id', 'groupname', 'status', 'createdat','updatedat','createdby','action'];
  dataSource = ELEMENT_DATA;
  account_dialog(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = { allColumns: 'sk'};
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.position = { top: "150px", right: '10px' }

    const dialogRef = this.dialog.open(AccountDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (typeof result == "object") {
        this.setColumn1(result);
      }
    });
  }
  settingClick1() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = { allColumns: this.allColumns };
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.position = { top: "150px", right: '10px' }

    const dialogRef = this.dialog.open(ColumnDialog, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (typeof result == "object") {
        this.setColumn1(result);
      }
    });
  }
  setColumn1(selColumn:any) {
    this.allColumns = [];
    this.displayedColumns = [];
    selColumn.forEach((element:any) => {
      this.allColumns.push(element);
      if (element.activeFlag) {
        this.displayedColumns.push(element.name);
      }
    });
    console.log(this.displayedColumns)
  }

 
}
